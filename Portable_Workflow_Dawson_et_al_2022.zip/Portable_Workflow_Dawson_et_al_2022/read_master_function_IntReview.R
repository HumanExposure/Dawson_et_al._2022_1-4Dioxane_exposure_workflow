#This script contains the SHEDS_Runs wrapper function sourced in using the Simulations_and_Data_Summary_IntReview.R script

library(readxl)
library(writexl)
#library(ShedsHT) #this isn't necessary here, but SHEDS-HT can be loaded from GitHub if desired
library(rstudioapi)
library(data.table)
library(doParallel)
library(parallel)




#Product Ids####
shampoo = c('P.PC.820.999','P.PC.820.004')
body_wash = c('P.PC.200.000')
water = c('DW','Water')
laundry_detergent = c('P.IH.260.013','P.IH.260.023','P.IH.260.999')
dish_soap= c('P.IH.090.000')
hand_soap = c('P.PC.610.000')
bubble_bath = c('P.PC.220.000')
all_sources = c(shampoo, body_wash,water,laundry_detergent,dish_soap,hand_soap,bubble_bath)

####Run Parameters####
run_names = list(
  'US_GW_low',
  'US_SW_low',
  'US_Mix_low',
  'US_GW_high',
  'US_SW_high',
  'US_Mix_high',
  'CA_GW_low',
  'CA_SW_low',
  'CA_Mix_low',
  'CA_GW_high',
  'CA_SW_high',
  'CA_Mix_high'
)


Sheds_runs = function(wd = NULL,initials = 'haf',sample = 10000, run_loop_name="Test2",sources = all_sources,run_names = run_names, CASofInterest='123-91-1', cores = NULL, inputfile="master_inputs.xlsx"){
  if (is.null(cores)){
    cores=(detectCores() - 2) #unless stated in the run, use all but 2 cores
  }
  registerDoParallel(cores=cores)
  
  #Set up####
  if(is.null(wd)){ #Set to is.null
    wd = dirname(rstudioapi::getSourceEditorContext()$path)
  }
  
  ##This sets up the other SHEDS-HT scripts for sourcing into the parallel processing routine so the package doesn't need to be downloaded and installed
  sheds_pth1 = paste0(wd,"/SHEDS_R/ShedsHT_IntReview.R")         #path used to source sHEDS
  sheds_pth2 = paste0(wd,"/SHEDS_R/Utility.R")         #path used to source sHEDS
  sheds_pth3 = paste0(wd,"/SHEDS_R/Fugacity.R")         #path used to source sHEDS

  #Set the working directory
  setwd(wd)
  
  #set up directories
  date = gsub('([[:punct:]])|//s+','_',Sys.Date()) 
  dir.create(paste0('SHEDS_loop_',run_loop_name,'_',date))

  #Data listss 
  all_compiled = list()
  srcmean_compiled = list()
  stats_compiled = list()
  
  #Import source files
  vars_master = read_xlsx(inputfile,sheet = 'src_var')
  prev_master = read_xlsx(inputfile,sheet = 'src_chem_prev')
  conc_master = read_xlsx(inputfile,sheet = 'src_chem_conc')
  scen_master = read_xlsx(inputfile,sheet = 'src_scen')
  act_diary = read_xlsx(inputfile,sheet = 'act.diary')
  chem_props = read_xlsx(inputfile,sheet = 'chem.props')
  diet_diary = read_xlsx(inputfile,sheet = 'diet.diary')
  exp_factors = read_xlsx(inputfile,sheet = 'exp.factors')
  fugacity = read_xlsx(inputfile,sheet = 'fugacity')
  media = read_xlsx(inputfile,sheet = 'media')
  physiology = read_xlsx(inputfile,sheet = 'physiology')
  population = read_xlsx(inputfile,sheet = 'population')
  
  water = c('DW','Water') #to split runs by products and water
  
  ####BEGIN LOOP####################
  
  #for (i in 1:length(run_names))
  foreach(i = 1:length(run_names)) %dopar%{ 

    #Load the SHEDS-HT scripts 
    source(sheds_pth1)
    source(sheds_pth2)
    source(sheds_pth3)
    
    run_name= as.character(run_names[i])
    
    run_cats = strsplit(run_name,'_')[[1]]
    
    area = run_cats[1]
    water_type = run_cats[2]
    prod_prev = run_cats[3]
    
    ###Source Vars####

    vars_temp = vars_master[vars_master$source.id %in% sources,]
    vars_products = vars_temp[grepl(area,vars_temp$run_param), ]
    
    if (nrow(vars_products) == 0){
      vars_products = vars_master[!is.na(vars_master$form),]
    }
    
    ###Source Chem####
    
    #Prev
    prev_final = prev_master[(grepl(area,prev_master$run_param) & grepl(water_type,prev_master$run_param))|
                              grepl(prod_prev,prev_master$run_param) ,]
    
    #Conc
    conc_final = conc_master[(grepl(area,conc_master$run_param) & grepl(water_type,conc_master$run_param))|
                               grepl(prod_prev,conc_master$run_param) ,]
    
    #combine
    chem_final = rbind(prev_final,conc_final)
    
    chem_prod  = chem_final[!chem_final$Source.ID %in% water,]
    chem_water = chem_final[ chem_final$Source.ID %in% water,]
    
    ###Source Scen####
    scen_products = scen_master
    
    ###Other inputs####
    
    
    #Run Files
    run_file_prod  = data.frame(matrix(NA, nrow = 24, ncol = 2))
    run_file_water = data.frame(matrix(NA, nrow = 24, ncol = 2))
    variables = c('run.name         =', 
                  'n.persons        =',
                  'person.output    =', 
                  'source.output    =', 
                  'min.age          =', 
                  'max.age          =',
                  'genders          =',  
                  'seasons          =', 
                  'details          =', 
                  'age.match.pct    =', 
                  'run.seed         =', 
                  'set.size         =', 
                  'act.diary.file   =',
                  'chem.props.file  =', 
                  'diet.diary.file  =', 
                  'exp.factor.file  =',     
                  'fugacity.file    =',     
                  'media.file       =',
                  'physiology.file  =', 
                  'population.file  =', 
                  'source.vars.file =', 
                  'source.scen.file =', 
                  'source.chem.file =', 
                  'chemical         ='
    )
    
    values_prod = c(run_name,
               sample,             
               'yes',
               'yes',
               0,
               99,
               'FM',
               'PSFW',
               1,
               20,
               876144637,
               sample,
               paste0('act_diary_',run_name,'.csv'),
               paste0('chem_props_',run_name,'.csv'),
               paste0('diet_diary_',run_name,'.csv'),
               paste0('exp_factors_',run_name,'.csv'),
               paste0('fugacity_',run_name,'.csv'),
               paste0('media_',run_name,'.csv'),
               paste0('physiology_',run_name,'.csv'),
               paste0('population_',run_name,'.csv'),
               paste0('source_vars_',run_name,'.csv'),
               paste0('source_scen_',run_name,'.csv'),
               paste0('source_chem_',run_name,'_prod.csv'),
               CASofInterest
    )
    values_water = c(run_name,
                    sample,             
                    'yes',
                    'yes',
                    0,
                    99,
                    'FM',
                    'PSFW',
                    1,
                    20,
                    876144637,
                    sample,
                    paste0('act_diary_',run_name,'.csv'),
                    paste0('chem_props_',run_name,'.csv'),
                    paste0('diet_diary_',run_name,'.csv'),
                    paste0('exp_factors_',run_name,'.csv'),
                    paste0('fugacity_',run_name,'.csv'),
                    paste0('media_',run_name,'.csv'),
                    paste0('physiology_',run_name,'.csv'),
                    paste0('population_',run_name,'.csv'),
                    paste0('source_vars_',run_name,'.csv'),
                    paste0('source_scen_',run_name,'.csv'),
                    paste0('source_chem_',run_name,'_water.csv'),
                    CASofInterest
    )
    run_file_prod[,1] = variables
    run_file_prod[,2] = values_prod
    
    run_file_water[,1] = variables
    run_file_water[,2] = values_water
    
    
    colnames(run_file_prod) = c('Variable,','Value')
    colnames(run_file_water) = c('Variable,','Value')
    
    ###Create SHeDS Files####
    
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date))
    
    dir.create(paste0('SHEDS_',run_name))
    
    dir.create(paste0('SHEDS_',run_name,'/prod_run'))
    dir.create(paste0('SHEDS_',run_name,'/prod_run/Inputs'))
    dir.create(paste0('SHEDS_',run_name,'/prod_run/output'))
    
    dir.create(paste0('SHEDS_',run_name,'/water_run'))
    dir.create(paste0('SHEDS_',run_name,'/water_run/Inputs'))
    dir.create(paste0('SHEDS_',run_name,'/water_run/output'))
  
    
  ###Prod inputs
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date,'/SHEDS_',run_name,'/prod_run/Inputs'))
    
    write.csv(scen_products,paste0('source_scen_',run_name,'.csv'))
    write.csv(vars_products,paste0('source_vars_',run_name,'.csv'))
    write.csv(chem_prod,paste0('source_chem_',run_name,'_prod.csv'))
    write.csv(act_diary,paste0('act_diary_',run_name,'.csv'))
    
    #DED:Subset Chemical properties file to CASofInterest
    chem_props1=chem_props[chem_props$CAS==CASofInterest,]
    write.csv(chem_props1,paste0('chem_props_',run_name,'.csv'))
    
    write.csv(diet_diary,paste0('diet_diary_',run_name,'.csv'))
    write.csv(exp_factors,paste0('exp_factors_',run_name,'.csv'))
    write.csv(fugacity,paste0('fugacity_',run_name,'.csv'))
    write.csv(media,paste0('media_',run_name,'.csv'))
    write.csv(physiology,paste0('physiology_',run_name,'.csv'))
    write.csv(population,paste0('population_',run_name,'.csv'))
    
    write.table(run_file_prod,paste0(run_name,'_prod.txt'),row.names = FALSE, quote = FALSE)
  
    
  ###Water Inputs
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date,'/SHEDS_',run_name,'/water_run/Inputs'))
    
    write.csv(scen_products,paste0('source_scen_',run_name,'.csv'))
    write.csv(vars_products,paste0('source_vars_',run_name,'.csv'))
    write.csv(chem_water,paste0('source_chem_',run_name,'_water.csv'))
    write.csv(act_diary,paste0('act_diary_',run_name,'.csv'))
    
    #DED:Subset Chemical properties file to CASofInterest
    chem_props1=chem_props[chem_props$CAS==CASofInterest,]
    write.csv(chem_props1,paste0('chem_props_',run_name,'.csv'))
    
    write.csv(diet_diary,paste0('diet_diary_',run_name,'.csv'))
    write.csv(exp_factors,paste0('exp_factors_',run_name,'.csv'))
    write.csv(fugacity,paste0('fugacity_',run_name,'.csv'))
    write.csv(media,paste0('media_',run_name,'.csv'))
    write.csv(physiology,paste0('physiology_',run_name,'.csv'))
    write.csv(population,paste0('population_',run_name,'.csv'))
    
    write.table(run_file_water,paste0(run_name,'_water.txt'),row.names = FALSE, quote = FALSE)
    
    
    ###Run SHEDS####
    
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date,'/SHEDS_',run_name,'/prod_run'))
    run_rev(paste0(run_name,'_prod.txt'))
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date,'/SHEDS_',run_name,'/water_run'))
    run_rev(paste0(run_name,'_water.txt'))
    
    ####Grab the required files from each####
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date,'/SHEDS_',run_name,'/prod_run/output/',run_name))
    all_prod = read.csv("CAS_123_91_1_all.csv")
    src_prod = read.csv('CAS_123_91_1_all_srcMeans.csv')
    stats_prod = read.csv("CAS_123_91_1_allstats.csv" )
    
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date,'/SHEDS_',run_name,'/water_run/output/',run_name))
    all_water = read.csv("CAS_123_91_1_all.csv")
    src_water = read.csv('CAS_123_91_1_all_srcMeans.csv')
    stats_water = read.csv("CAS_123_91_1_allstats.csv" )
   
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date,'/SHEDS_',run_name))
    dir.create(paste0('Total'))
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date,'/SHEDS_',run_name,'/Total'))
    write.csv(all_prod,file = paste0('all_prod_',initials,'_',date,'.csv'))
    write.csv(src_prod,file = paste0('src_prod_',initials,'_',date,'.csv'))
    write.csv(stats_prod,file = paste0('stats_prod_',initials,'_',date,'.csv'))
    write.csv(all_water,file = paste0('all_water_',initials,'_',date,'.csv'))
    write.csv(src_water,file = paste0('src_water_',initials,'_',date,'.csv'))
    write.csv(stats_water,file = paste0('stats_water_',initials,'_',date,'.csv'))
    
      #combine 'all' files
    all_total = data.frame( )
    all_total = all_prod[,c('person','gender','age','season','weekend','weight')]
    all_total[,7:26] = all_prod[,7:26]+all_water[,7:26]
    names(all_total) = names(all_prod)
    
    write.csv(all_total,file = paste0('all_total_',initials,'_',date,'.csv'))
    
    
  }
  for (i in 1:length(run_names)){
    
    run_name = as.character(run_names[i])
    setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date,'/SHEDS_',run_name,'/Total'))
    
    #save output of each run in dataframe
    all_compiled[[3*i-2]] = read.csv(paste0('all_total_',initials,'_',date,'.csv'))
    all_compiled[[3*i-1]] = read.csv(paste0('all_prod_' ,initials,'_',date,'.csv'))
    all_compiled[[3*i]]   = read.csv(paste0('all_water_',initials,'_',date,'.csv'))
    
    srcmean_compiled[[2*i-1]] = read.csv(paste0('src_water_',initials,'_',date,'.csv'))
    srcmean_compiled[[2*i]] = read.csv(paste0('src_water_',initials,'_',date,'.csv'))
    
    stats_compiled[[2*i-1]] = read.csv(paste0('stats_prod_',initials,'_',date,'.csv'))
    stats_compiled[[2*i]]  = read.csv(paste0('stats_water_',initials,'_',date,'.csv'))
    
    names(all_compiled)[3*i-2] = paste0(run_name,'_total')
    names(all_compiled)[3*i-1] = paste0(run_name,'_products')
    names(all_compiled)[3*i]   = paste0(run_name,'_water')
    
    names(srcmean_compiled)[2*i-1] = paste0(run_name,'_products')
    names(srcmean_compiled)[2*i]   = paste0(run_name,'_water')
    
    names(stats_compiled)[2*i-1] = paste0(run_name,'_products')
    names(stats_compiled)[2*i] = paste0(run_name,'_water')

  }
  Output = list(
    All = all_compiled,
    Srcmean = srcmean_compiled,
    Stats = stats_compiled)

  setwd(paste0(wd,'/SHEDS_loop_',run_loop_name,'_',date))  
  save(Output, file=paste("SHEDS_HT_CompiledOutputs_", length(run_names),"_Scenarios_", initials,"_", date, ".RData",sep=""))
  return(Output)
}

