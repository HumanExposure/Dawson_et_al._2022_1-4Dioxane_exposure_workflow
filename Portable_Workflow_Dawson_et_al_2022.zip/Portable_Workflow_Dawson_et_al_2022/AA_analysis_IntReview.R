##Alternative Analysis Script
#PREVIOUS SCRIPT IN WORKFLOW:Simulations_and_Data_Summary_IntRev_071421.R.R

#THis script sources in and works with "read_master_function_aa_IntReview.R"; see that script to see options

#ADDITIONAL Scripts in workflow: 
#Data_analysis_IntReview_071421.R
#Wastewater_Evaluation_Script_IntReview_071421.R  


wd = dirname(rstudioapi::getSourceEditorContext()$path) #sets path to wherever the files reside
setwd(wd)

#This will run a scenarios for AA analysis 
source('read_master_function_aa_IntReview.R') #Use this to run the AA script
UID="DED" #user initials
date = gsub('([[:punct:]])|//s+','_',Sys.Date()) #This grabs the date

#Run with a  product threshold scenario, note that the threshold is specified via the "th" arguement. 1e-6=1ppm in terms of weight fraction 
a=Sys.time()
Sheds_runs(initials = UID,sample = 10000, run_loop_name="AA_Product",sources = all_sources,run_names = run_names, CASofInterest='123-91-1',inputfile="master_inputs.xlsx", th=1e-6)   
Sys.time() - a

#Run without a product threshold
a=Sys.time()
Sheds_runs(initials = UID,sample = 10000, run_loop_name="AA_Control",sources = all_sources,run_names = run_names, CASofInterest='123-91-1',inputfile="master_inputs.xlsx", th=NA)   
Sys.time() - a


#NOw, load the scenarios run above to compare the outcomes
datelabel=date
wd = dirname(rstudioapi::getSourceEditorContext()$path) #sets path to wherever the files reside
setwd(wd)
load(paste0("SHEDS_loop_AA_Control_",datelabel,"/SHEDS_HT_CompiledOutputs_3_Scenarios_",UID,"_", datelabel,".RData"))
Control=Output
load(paste0("SHEDS_loop_AA_Product_",datelabel,"/SHEDS_HT_CompiledOutputs_3_Scenarios_",UID,"_", datelabel,".RData"))

AA=Output
names(AA$All)
GTAA=AA$All$CA_GW_high_total
STAA=AA$All$CA_SW_high_total
MTAA=AA$All$CA_Mix_high_total

GTC=Control$All$CA_GW_high_total
STC=Control$All$CA_SW_high_total
MTC=Control$All$CA_Mix_high_total

#Specify treatment categories
GTAA$Treatment="AA"
STAA$Treatment="AA"
MTAA$Treatment="AA"
GTC$Treatment="No Action"
STC$Treatment="No Action"
MTC$Treatment="No Action"

#Specify water categories
GTAA$Water="Ground"
STAA$Water="Surface"
MTAA$Water="Mixed"
GTC$Water="Ground"
STC$Water="Surface"
MTC$Water="Mixed"

#Note that abs.ingestion occurs to a small degree through the dermal scenario due to hand to mouth behavior. So, to separate out people
#by water exposure, use the exp.diet columan. 
AAdata=data.frame(rbind(GTAA,STAA,MTAA,GTC,STC,MTC))
AAdata$abs.tot.mgkg=AAdata$abs.tot.mgkg+0.000000001
AAdata$exp.drain=AAdata$exp.drain+0.000000001
POAAdata=AAdata[AAdata$exp.diet==0,]
BothAAdata=AAdata[AAdata$exp.diet>0,]

dir.create('AAComparisons')
save(AAdata, file=paste0("AAComparisons/AlternativeAssessment_",UID,"_", datelabel,".RData"))
#Note, unicode for mu(u) is \u03bc

#Human Exposure
#Total
resulttabTotal=NULL
Water=c("Ground", "Mixed", "Surface")
for(i in Water){
  Tdata=AAdata[c(AAdata$Water==i & AAdata$Treatment=="AA"),"abs.tot.mgkg"]
  Cdata=AAdata[c(AAdata$Water==i & AAdata$Treatment=="No Action"),"abs.tot.mgkg"]
  TT=t.test(log10(Tdata), log10(Cdata), alternative="less",paired=FALSE, var.equal = TRUE)
  PerDiff=(mean(Cdata)-mean(Tdata))/mean(Cdata)
  resulttabTotal=rbind(resulttabTotal, c(mean(Cdata),sd(Cdata), mean(Tdata),sd(Tdata), PerDiff, TT$statistic, TT$p.value))}




#ProductsOnly
resulttabPO=NULL
Water=c("Ground", "Mixed", "Surface")
for(i in Water){
  Tdata=POAAdata[c(POAAdata$Water==i & POAAdata$Treatment=="AA"),"abs.tot.mgkg"]
  Cdata=POAAdata[c(POAAdata$Water==i & POAAdata$Treatment=="No Action"),"abs.tot.mgkg"]
  TT=t.test(log10(Tdata), log10(Cdata), alternative="less",paired=FALSE)
  PerDiff=(mean(Cdata)-mean(Tdata))/mean(Cdata)
  resulttabPO=rbind(resulttabPO, c(mean(Cdata),sd(Cdata), mean(Tdata),sd(Tdata), PerDiff, TT$statistic, TT$p.value))}


#Both
resulttabBoth=NULL
Water=c("Ground", "Mixed", "Surface")
for(i in Water){
  Tdata=BothAAdata[c(BothAAdata$Water==i & BothAAdata$Treatment=="AA"),"abs.tot.mgkg"]
  Cdata=BothAAdata[c(BothAAdata$Water==i & BothAAdata$Treatment=="No Action"),"abs.tot.mgkg"]
  TT=t.test(log10(Tdata), log10(Cdata), alternative="less",paired=FALSE)
  PerDiff=(mean(Cdata)-mean(Tdata))/mean(Cdata)
  resulttabBoth=rbind(resulttabBoth, c(mean(Cdata),sd(Cdata), mean(Tdata),sd(Tdata), PerDiff, TT$statistic, TT$p.value))}

ResultsAAHE=data.frame("Water"=rep(Water,3), "Subpopulation"=c(rep("Total",3), rep("ProductsOnly",3), rep("Both",3)),rbind(resulttabTotal, resulttabPO, resulttabBoth))
names(ResultsAAHE)=c("Water", "Subpopulation","No_Action","No_Action_SD", "Threshold", "Thresold_SD","Percent_Difference", "t-statistic", "p-value")
write.csv(ResultsAAHE, file=paste0("AAComparisons/AAComparison_HE_", UID, "_", datelabel,".csv"))


##
#DTD
#Total
resulttabTotal=NULL
Water=c("Ground", "Mixed", "Surface")
for(i in Water){
  Tdata=AAdata[c(AAdata$Water==i & AAdata$Treatment=="AA"),"exp.drain"]
  Cdata=AAdata[c(AAdata$Water==i & AAdata$Treatment=="No Action"),"exp.drain"]
  TT=t.test(log10(Tdata), log10(Cdata), alternative="less",paired=FALSE)
  PerDiff=(mean(Cdata)-mean(Tdata))/mean(Cdata)
  resulttabTotal=rbind(resulttabTotal, c(mean(Cdata),sd(Cdata), mean(Tdata),sd(Tdata), PerDiff, TT$statistic, TT$p.value))}

#ProductsOnly
resulttabPO=NULL
Water=c("Ground", "Mixed", "Surface")
for(i in Water){
  Tdata=POAAdata[c(POAAdata$Water==i & POAAdata$Treatment=="AA"),"exp.drain"]
  Cdata=POAAdata[c(POAAdata$Water==i & POAAdata$Treatment=="No Action"),"exp.drain"]
  TT=t.test(log10(Tdata), log10(Cdata), alternative="less",paired=FALSE)
  PerDiff=(mean(Cdata)-mean(Tdata))/mean(Cdata)
  resulttabPO=rbind(resulttabPO, c(mean(Cdata),sd(Cdata), mean(Tdata),sd(Tdata), PerDiff, TT$statistic, TT$p.value))}


#Both
resulttabBoth=NULL
Water=c("Ground", "Mixed", "Surface")
for(i in Water){
  Tdata=BothAAdata[c(BothAAdata$Water==i & BothAAdata$Treatment=="AA"),"exp.drain"]
  Cdata=BothAAdata[c(BothAAdata$Water==i & BothAAdata$Treatment=="No Action"),"exp.drain"]
  TT=t.test(log10(Tdata), log10(Cdata), alternative="less",paired=FALSE)
  PerDiff=(mean(Cdata)-mean(Tdata))/mean(Cdata)
  resulttabBoth=rbind(resulttabBoth, c(mean(Cdata),sd(Cdata), mean(Tdata),sd(Tdata), PerDiff, TT$statistic, TT$p.value))}

ResultsAADTD=data.frame("Water"=rep(Water,3), "Subpopulation"=c(rep("Total",3), rep("ProductsOnly",3), rep("Both",3)),rbind(resulttabTotal, resulttabPO, resulttabBoth))
names(ResultsAADTD)=c("Water", "Subpopulation","No_Action","No_Action_SD", "Threshold", "Thresold_SD","Percent_Difference", "t-statistic", "p-value")
write.csv(ResultsAADTD, file=paste0("AAComparisons/AAComparison_DTD_", UID, "_", datelabel,".csv"))



