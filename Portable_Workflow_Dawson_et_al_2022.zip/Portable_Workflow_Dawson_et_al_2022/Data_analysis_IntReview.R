###Factorial Analyses Script

#PREVIOUS SCRIPT IN WORKFLOW: Simulations_and_Data_Summary_IntRev.R
#ADDITIONAL Scripts in workflow: 
#AA_Analysis_IntReview.R
#Wastewater_Evaluation_Script_IntReview.R  


#This script performs statistical analyses of factorial simulations run via "Simulations_and_Data_Summary_IntRevew.R".
#Make sure to specify the the correct datelabel and runlabels below to align with the simulation outputs.


#Analyses performed
#1. ANOVAS for Human Exposure and DTD Exposure for 
#a.Aggreate population
#b.Only Product people
#c.Water and Product People 

#2.Logistic regression for proportion of exposure due to water for
#a.Human Exposure
#b.DTD exposure 


wd = dirname(rstudioapi::getSourceEditorContext()$path) #sets path to wherever the files reside
runlabel=simulation_exp_name
datelabel= date
setwd(paste0(wd,"/SHEDS_loop_", runlabel,"_",datelabel))

#Make factorial output table with factorial conditions as columns
Total=NULL
D=Output$All
for(i in 1:length(D)){
    set=D[[i]]
    names1=unlist(strsplit(names(D)[i], "_"))
    set$Spatial=names1[1]
    set$Water=names1[2]
    set$Prev=names1[3]
    set$Set=names1[4]

Total=rbind(Total, set)
    }


Combined=Total[Total$Set=="total",]
Water=Total[Total$Set=="water",]
Products=Total[Total$Set=="products",]

save(Combined, file=paste0("TotalWaterProducts_",datelabel,".RData"))
save(Water, file=paste0("Water_",datelabel,".RData"))
save(Products, file=paste0("Products_",datelabel,".RData"))


load(paste0("TotalWaterProducts_",datelabel,".RData"))
load(paste0("Water_",datelabel,".RData"))
load(paste0("Products_",datelabel,".RData"))


#Analysis: 6, three-way ANOVAS for the main human exposure and DTD analysis
#Note: add a very small amount of variation to prevent error when using log transformation
library(sjstats) #To produce eta statistics
Combined$Prev=as.factor(Combined$Prev)
ProdOnly=Combined[Combined$exp.diet==0,]
WaterProd=Combined[Combined$exp.diet>0, ]
#Analysis:Comparison 
#Products and Water
quantile(Combined$abs.tot.mgkg, 0.05) #1x10-9 added to avoid errors for taking log of 0 
HEmod1=aov(lm(log10(Combined$abs.tot.mgkg+0.0000000001)~Combined$Prev+Combined$Spatial*Combined$Water)) 
plot(HEmod1)
summary(HEmod1) #Significant reduction of exposure
HE1=anova_stats(HEmod1)[1:8]
THEmod1=TukeyHSD(HEmod1)
names(THEmod1)
interaction.plot(Combined$Water, Combined$Spatial,log10(Combined$abs.tot.mgkg+0.0000000001))
history(Combined$abs.tot.mgkg)

Combinedtab2=aggregate(exp.drain~Spatial* Water, data=Combined, FUN="mean")
quantile(Combined$exp.drain, 0.05)
DTDmod1=aov(lm(log10(Combined$exp.drain+0.0000000001)~Combined$Prev + Combined$Spatial * Combined$Water))
plot(DTDmod1)
summary(DTDmod1) #No impact of water source significant interaction, but impact of treatment 
DTD1=anova_stats(DTDmod1)[1:8]
interaction.plot(Combined$Water, Combined$Spatial,log10(Combined$exp.drain+0.0000000001))
hist(log(Combined$exp.drain))


#Products-Only
quantile(ProdOnly$abs.tot.mgkg, 0.05)
HEmod2=aov(lm(log10(ProdOnly$abs.tot.mgkg+0.0000000001)~ProdOnly$Prev))
plot(HEmod2)
summary(HEmod2) #No impact of water source significant interaction, but impact of treatment 
TukeyHSD(HEmod2)
HE2=anova_stats(HEmod2)[1:8]

quantile(ProdOnly$exp.drain, 0.05)
DTDmod2=aov(lm(log10(ProdOnly$exp.drain+0.0000000001)~ProdOnly$Prev))
plot(DTDmod2)
summary(DTDmod2) #No impact of water source significant interaction, but impact of treatment 
TukeyHSD(DTDmod2)
DTD2=anova_stats(DTDmod2)[1:8]


#Both Water and Products
quantile(WaterProd$abs.tot.mgkg, 0.05)
HEmod3=aov(lm(log10(WaterProd$abs.tot.mgkg+0.0000000001)~WaterProd$Prev+WaterProd$Spatial * WaterProd$Water))
plot(HEmod3)
summary(HEmod3) #No impact of water source significant interaction, but impact of treatment 
TukeyHSD(HEmod3)
HE3=anova_stats(HEmod3)[1:8]
interaction.plot(WaterProd$Water, WaterProd$Spatial,log10(WaterProd$abs.tot.mgkg+0.0000000001))


quantile(WaterProd$exp.drain, 0.05)
DTDmod3=aov(lm(log10(WaterProd$exp.drain)~WaterProd$Prev+WaterProd$Spatial * WaterProd$Water))
plot(DTDmod3)
summary(DTDmod3) #No impact of water source significant interaction, but impact of treatment 
TukeyHSD(DTDmod3)
DTD3=anova_stats(DTDmod3)[1:8]
interaction.plot(WaterProd$Water, WaterProd$Spatial,log10(WaterProd$exp.drain+0.0000000001))


#Combined tables
HEtab=rbind(HE1,HE2, HE3)
DTDtab=rbind(DTD1, DTD2, DTD3)

###Proportion##Switching over to Beta regression and Coen's D for effect size. 
#Compile HE and DTD together
library(betareg)
library(effectsize)
runs=names(Output$All)

#This extracts all of the elements of the list with water or products in their name
Allwater = Output$All[grepl('water',runs)]
Allprods=Output$All[grepl('products',runs)]

#Read in water and product sets
WaterTab=NULL
for(i in 1:length(Allwater)){
  name=unlist(strsplit(names(Allwater[i]),"_"))
  w1=Allwater[[i]]
  w1$Spatial=name[1]
  w1$Water=name[2]
  w1$Prev=name[3]
  w1$Pathway=name[4]
WaterTab=rbind(WaterTab, w1)  
  }

ProductsTab=NULL
for(i in 1:length(Allprods)){
  name=unlist(strsplit(names(Allprods[i]),"_"))
  p1=Allprods[[i]]
  p1$Spatial=name[1]
  p1$Water=name[2]
  p1$Prev=name[3]
  p1$Pathway=name[4]
  ProductsTab=rbind(ProductsTab, p1)  
}


TotalTab=merge(ProductsTab, WaterTab, by=c("person", "Spatial", "Water", "Prev"), suffixes=c(".products", ".water"))
TotalTab=TotalTab[TotalTab$exp.diet.water>0,] #Separate out just the Both people

TotalTab$Count=1


#Proportion of human exposure that is from products
TotalTab$abs.tot.mgkg=TotalTab$abs.tot.mgkg.products+TotalTab$abs.tot.mgkg.water
TotalTab$HEPropwater=TotalTab$abs.tot.mgkg.water/TotalTab$abs.tot.mgkg
TotalTab$HEPropproducts=TotalTab$abs.tot.mgkg.products/TotalTab$abs.tot.mgkg

#Proportion of DTD that is from products
TotalTab$exp.drain=TotalTab$exp.drain.products +TotalTab$exp.drain.water
TotalTab$DTDPropwater=TotalTab$exp.drain.water/TotalTab$exp.drain
TotalTab$DTDPropproducts=TotalTab$exp.drain.products/TotalTab$exp.drain

boxplot(TotalTab$HEPropwater~TotalTab$Prev+TotalTab$Spatial+TotalTab$Water)
aggregate(TotalTab$HEPropwater~TotalTab$Prev+TotalTab$Spatial+TotalTab$Water, FUN="median")
boxplot(TotalTab$DTDPropwater~TotalTab$Prev+TotalTab$Spatial+TotalTab$Water)


#Beta Regression and Cohen's D
#Have to do 6 model fits test different reference levels in order to get OR for each. 
##Human Exposure:
#Both Subpopulation

#Re-scale the data so that there are no zero's or 1's. 
transform01 <- function(x) {
  (x * (length(x) - 1) + 0.5) / (length(x)) #Suggested by Douma and Wheedon, 2019. 
}

TotalTab$Water=as.factor(TotalTab$Water)
TotalTab$Spatial=as.factor(TotalTab$Spatial)
TotalTab$Prev=as.factor(TotalTab$Prev)
#Rescaled 
TotalTab$HEPropwatersc=transform01(TotalTab$HEPropwater)
TotalTab$DTDPropproductssc=transform01(TotalTab$DTDPropproducts)

HEwaterpropmod1=betareg(HEPropwatersc~Prev + Spatial * Water, data=TotalTab)
summary(HEwaterpropmod1) #Shows no significant interaction, so need to provide differences for main groups:


#high-low prev
#US-CA
#GW-SW
#GW-Mixed
#SW-Mixed

#Cohen's D estimate
CDHEPrev=cohens_d(HEPropwatersc~Prev, data = TotalTab, pooled_sd = TRUE)
CDHESpace=cohens_d(HEPropwatersc~Spatial, data = TotalTab, pooled_sd = TRUE)
CDHEGWSW=cohens_d(HEPropwatersc~Water, data = TotalTab[TotalTab$Water=="GW" | TotalTab$Water=="SW", ], pooled_sd = TRUE)
CDHEGWMix=cohens_d(HEPropwatersc~Water, data = TotalTab[TotalTab$Water=="GW" | TotalTab$Water=="Mix", ], pooled_sd = TRUE)
CDHESWMix=cohens_d(HEPropwatersc~Water, data = TotalTab[TotalTab$Water=="SW" | TotalTab$Water=="Mix", ], pooled_sd = TRUE)
HEproptab=data.frame("var1"=c("High", "CA", "GW", "GW", "Mix"), "var2"=c("Low", "US", "SW", "Mix", "SW"), rbind(CDHEPrev, CDHESpace, CDHEGWSW, CDHEGWMix, CDHESWMix))


DTDproductpropmod1=betareg(DTDPropproductssc~Prev + Spatial * Water, data=TotalTab)
plot(DTDproductpropmod1)
summary(DTDproductpropmod1) #Shows no significant interaction, so need to provide differences for main groups:
#high-low prev
#US-CA
#GW-SW
#GW-Mixed
#SW-Mixed

#Cohen's D estimate
CDDTDPrev=cohens_d(DTDPropproducts~Prev, data = TotalTab, pooled_sd = TRUE)
CDDTDSpace=cohens_d(DTDPropproducts~Spatial, data = TotalTab, pooled_sd = TRUE)
CDDTDGWSW=cohens_d(DTDPropproducts~Water, data = TotalTab[TotalTab$Water=="GW" | TotalTab$Water=="SW", ], pooled_sd = TRUE)
CDDTDGWMix=cohens_d(DTDPropproducts~Water, data = TotalTab[TotalTab$Water=="GW" | TotalTab$Water=="Mix", ], pooled_sd = TRUE)
CDDTDSWMix=cohens_d(DTDPropproducts~Water, data = TotalTab[TotalTab$Water=="SW" | TotalTab$Water=="Mix", ], pooled_sd = TRUE)
DTDproptab=data.frame("var1"=c("High", "CA", "GW", "GW", "Mix"), "var2"=c("Low", "US", "SW", "Mix", "SW"), rbind(CDDTDPrev, CDDTDSpace, CDDTDGWSW, CDDTDGWMix, CDDTDSWMix))



