#Note: Need to install ShedsHT for this to work; but have to use older version of sheds. 


#MAIN SIMULATION AND SUMMARY SCRIPT

#This is the first script in the workflow to produce the results presented in Dawson et al. 2021 manuscript. 
#This script uses the wrapper function sourced from "read_master_function_IntReview.R" to 
#run the factorial simulations via SHEDS-HT. It then processes the outputs from these simulations for description and further
#analysis. 

##The NEXT SCRIPTS IN WORKFLOW: 
##Data_analysis_IntReview.R
##AA_Analysis_IntReview.R
##Wastewater_Evaluation_Script_IntReview.R


#NOTE TO THE USER: 
#The script is currently set up to replicate the study results of the manuscript. To run a new scenario, the user
#will need to modify the scenarios on the "read_master_function_IntReview.R", and/or modify the input file ("master_inputs.xlsx")
#Note that all of the relevant files and scripts to run SHEDS-HT are included 
#in the files of this folder and in the associated scripts, and it is NOT necessary to download the SHEDS-HT package.
#However, this package can be downloaded at the following GitHub repo: 
#https://github.com/HumanExposure/SHEDSHTRPackage

library(stringr)
library(rlist)
library(stats)
library(reshape2)
library(ggplot2)
library(data.table)
library(gridExtra)
library(RColorBrewer)

wd = dirname(rstudioapi::getSourceEditorContext()$path) #sets path to wherever the files reside
setwd(wd)
#Source SHEDS-HT scripts
source('read_master_function_IntReview.R')

#Input USER ID and the name of the simulation series
UID="DED" #user initials
simulation_exp_name="Example"

date = gsub('([[:punct:]])|//s+','_',Sys.Date()) #This grabs the date
a=Sys.time()
output_Table = Sheds_runs(initials = UID,sample = 10000, run_loop_name=simulation_exp_name,sources = all_sources,run_names = run_names, CASofInterest='123-91-1',inputfile="master_inputs.xlsx")   
Sys.time() - a



########
run_names = list(
   'US_GW_low',
   'US_SW_low',
   'US_Mix_low',
   'US_GW_high',
   'US_SW_high',
   'US_Mix_high',
   'CA_GW_low',
   'CA_SW_low',
   'CA_Mix_low',
  'CA_GW_high',
  'CA_SW_high',
  'CA_Mix_high'
)

##Format for metrics:
##stat_Gender_Age
## Age 'min-max' (ex. '0-5','14-67') or 'All'
## Gender: 'M','F', or 'All'
## Stat: mean, sd, or 95%
desired_metrics = c('median_All_All','sd_All_All','95%_All_All') #Note that SHEDS actually produces output by gender and age as well as general population distributions. 

#####DED: Note: Need to re-make figures with proportion of DTD released due to product use

##subset function replaces total exposure values for individual/run combinations that do not fall into the 'subset' with NA
#later, stats function will ignore NA values, thereby ignoring that individual from the statistics for that run
# 'subgroup' can be either 'water exp' or 'no water exp'
#the first keeps those with exposure due to water while the second only keeps individuals who were not exposed via water in the given run
#With no subgroup, it just groups water/total runs together and pulls out age/gender and exposure columns
Sheds_output_subset = function(output_Table, run_names, subgroup = ''){
      output1 = output_Table$All[!grepl('product',names(output_Table$All))]
      output2 = lapply(output1, function(x) 
                                x[
                                    grepl('gender',names(x)) |
                                    grepl('age',names(x)) |
                                    grepl('abs.tot.mgkg',names(x))|
                                    grepl('exp.drain',names(x))
                                  ])
      output3 = list()
      for (i in run_names){
        water = output2[grepl(paste0(i,'_water'),names(output2))]
        total = output2[grepl(paste0(i,'_total'),names(output2))]
        products=output2[grepl(paste0(i,'_products'),names(output2))]
        output3[[i]] = data.table(
          Gender = water[[paste0(i,'_water')]]$gender,
          Age = water[[paste0(i,'_water')]]$age,
          tot_exp = total[[paste0(i,'_total')]]$abs.tot.mgkg,
          wat_exp = water[[paste0(i,'_water')]]$abs.tot.mgkg,
          wat_prop_exp = water[[paste0(i,'_water')]]$abs.tot.mgkg / total[[paste0(i,'_total')]]$abs.tot.mgkg,
          tot_dtd = total[[paste0(i,'_total')]]$exp.drain,
          wat_dtd = water[[paste0(i,'_water')]]$exp.drain,
          prod_dtd= products[[paste0(i,'_products')]]$exp.drain,
          wat_prop_dtd = water[[paste0(i,'_water')]]$exp.drain / total[[paste0(i,'_total')]]$exp.drain,
          prod_prop_dtd= 1-(water[[paste0(i,'_water')]]$exp.drain / total[[paste0(i,'_total')]]$exp.drain)
          )
        
        if(subgroup == 'water exp'){
          output3[[i]]$tot_exp = ifelse(output3[[i]]$wat_exp == 0,  NA, output3[[i]]$tot_exp)
          output3[[i]]$wat_prop_exp = ifelse(output3[[i]]$wat_exp == 0,  NA, output3[[i]]$wat_prop_exp)
          output3[[i]]$tot_dtd = ifelse(output3[[i]]$wat_exp == 0,  NA, output3[[i]]$tot_dtd)
          output3[[i]]$wat_prop_dtd = ifelse(output3[[i]]$wat_exp == 0,  NA, output3[[i]]$wat_prop_dtd)
          output3[[i]]$prod_prop_dtd = ifelse(output3[[i]]$wat_exp == 0,  NA, output3[[i]]$prod_prop_dtd)
          
          }
        if(subgroup == 'no water exp'){
          output3[[i]]$tot_exp = ifelse(output3[[i]]$wat_exp != 0,  NA, output3[[i]]$tot_exp)
          output3[[i]]$wat_prop_exp = ifelse(output3[[i]]$wat_exp != 0,  NA, output3[[i]]$wat_prop_exp)
          output3[[i]]$tot_dtd = ifelse(output3[[i]]$wat_exp != 0,  NA, output3[[i]]$tot_dtd)
          output3[[i]]$wat_prop_dtd = ifelse(output3[[i]]$wat_exp != 0,  NA, output3[[i]]$wat_prop_dtd)
          output3[[i]]$prod_prop_dtd = ifelse(output3[[i]]$wat_exp != 0,  NA, output3[[i]]$prod_prop_dtd)
          }
      }
      return(output3)
}


#Produces a table with 1 row for each run and 1 column for each of the 'desired_metrics'
  #'variable' can be set to 'tot_exp' (default) or 'wat_prop_exp'
  # For dtd, tot_dtd or wat_prop_dtd
Sheds_stats = function(input_table,desired_metrics, run_names, variable = 'tot_exp'){
  all_table = as.data.frame(input_table)
  output = data.table(Run = names(input_table))
    for (i in 1:length(desired_metrics)){
      X = strsplit(desired_metrics[i],'_')[[1]] #splits 'desired metric' into its two meaningful parts
      
      #Gender
      if (X[2] == 'All'){
        data_gender = all_table
      }else{
        sel_col_g = all_table[,grepl('Gender',names(all_table))][1]
        data_gender = all_table[sel_col_g == X[2],]
      }
      
      #Age
      if (X[3] == 'All'){
        data = data_gender
      }else{
        sel_col_a = data_gender[,grepl('Age',names(all_table))][1]
        ages = strsplit(X[3],'-')[[1]]
        data = data_gender[sel_col_a < as.numeric(ages[2]) & sel_col_a > as.numeric(ages[1]),]
      }
      
      
      if (X[1] == '95%'){
        output[,paste0(desired_metrics[i],'_', variable)] = sapply(data[grepl(variable,names(data))], FUN = quantile, probs = .95, na.rm = T)
        
      }else{
        output[,paste0(desired_metrics[i],'_', variable)] = sapply(data[grepl(variable,names(data))], FUN = X[1], na.rm = T)
       
        }
    }
  return(output)
}

#Note: to load Output_Table from a previous run, load compiled output file produced from the run function, and re-name appropriately. 


total_tbl = Sheds_output_subset(output_Table, run_names)
we_tbl  = Sheds_output_subset(output_Table, run_names, subgroup = 'water exp')
nwe_tbl = Sheds_output_subset(output_Table, run_names, subgroup = 'no water exp')

#Exp
Total      = Sheds_stats(total_tbl,desired_metrics, run_names)
Water_exp  = Sheds_stats(we_tbl ,desired_metrics, run_names)
Nwater_exp = Sheds_stats(nwe_tbl,desired_metrics, run_names)
Water_prop_total_exp = Sheds_stats(total_tbl ,desired_metrics, run_names, variable = 'wat_prop_exp')
Water_prop_water_exp = Sheds_stats(we_tbl ,desired_metrics, run_names, variable = 'wat_prop_exp')


#DTD
DTD_tot = Sheds_stats(total_tbl,desired_metrics, run_names,variable = 'tot_dtd')
DTD_Water_exp  = Sheds_stats(we_tbl ,desired_metrics, run_names,variable = 'tot_dtd')
DTD_Nwater_exp = Sheds_stats(nwe_tbl,desired_metrics, run_names,variable = 'tot_dtd')
DTD_Water_prop_Both = Sheds_stats(we_tbl ,desired_metrics, run_names, variable = 'wat_prop_dtd')
DTD_Water_prop_Total= Sheds_stats(total_tbl ,desired_metrics, run_names, variable = 'wat_prop_dtd')
DTD_Product_prop_Both = Sheds_stats(we_tbl ,desired_metrics, run_names, variable = 'prod_prop_dtd')
DTD_Product_prop_Total= Sheds_stats(total_tbl ,desired_metrics, run_names, variable = 'prod_prop_dtd')

#Writes tables of means
###CSV####
write.csv(Total,file = paste0('Exp_total_', UID, '_', date,  '.csv'))
write.csv(Water_exp,file = paste0('Exp_watexp_', UID, '_', date, '.csv'))
write.csv(Nwater_exp,file = paste0('Exp_nwatexp_', UID, '_', date, '.csv'))
write.csv(Water_prop_water_exp,file = paste0('Exp_watprop_Both_',  UID, '_', date, '.csv'))
write.csv(Water_prop_total_exp,file = paste0('Exp_watprop_Total_',  UID, '_', date, '.csv'))


write.csv(DTD_tot,file = paste0('DTD_total_', UID, '_', date, '.csv'))
write.csv(DTD_Water_exp,file = paste0('DTD_watexp_', UID, '_', date, '.csv'))
write.csv(DTD_Nwater_exp,file = paste0('DTD_nwatexp_',  UID, '_', date, '.csv'))
write.csv(DTD_Water_prop_Both,file = paste0('DTD_watprop_Both_', UID, '_', date, '.csv'))
write.csv(DTD_Water_prop_Total,file = paste0('DTD_watprop_Total_', UID, '_', date, '.csv'))



###Make Tables in R for ouput
IDCols=as.data.frame(do.call("rbind", strsplit(Water_exp$Run, "_")))
IDCols=do.call(rbind, replicate(3, as.data.frame(IDCols), simplify=FALSE))
Total$Subpopulation="Total"
Nwater_exp$Subpopulation="Products Only"
Water_exp$Subpopulation="Both"
DTD_tot$Subpopulation="Total"
DTD_Nwater_exp$Subpopulation="Products Only"
DTD_Water_exp$Subpopulation="Both"
HE=rbind(Total, Nwater_exp, Water_exp)
DTD=rbind(DTD_tot, DTD_Nwater_exp, DTD_Water_exp)
ExportTable=cbind(IDCols,HE, DTD)
#Clean up table:
ExportTable=ExportTable[,c(1:3,8,5:7,10:12)]
names(ExportTable)=c("Spatial", "Water", "Prevalence", "Subpopulation", "HEMedian", "HEStD", "HE95% Quantile","DTDMedian", "DTDStD", "DTD95% Quantile")
write.csv(ExportTable, file=paste0("DataSummaryTable_", UID,"_",date,".csv"))


##Water Proportion table
IDCols=as.data.frame(do.call("rbind", strsplit(Water_exp$Run, "_")))
IDCols=do.call(rbind, replicate(2, as.data.frame(IDCols), simplify=FALSE))
Water_prop_total_exp$Subpopulation="Total"
Water_prop_water_exp$Subpopulation="Both"
#DTD_Water_prop_Total$Subpopulation="Total"
#DTD_Water_prop_Both$Subpopulation="Both"
DTD_Product_prop_Both$Subpopulation="Both"
DTD_Product_prop_Total$Subpopulation="Total"
HE=rbind(Water_prop_total_exp, Water_prop_water_exp)
DTD=rbind(DTD_Product_prop_Total, DTD_Product_prop_Both)
ExportTable2=cbind(IDCols, HE, DTD)
ExportTable2=ExportTable2[,c(1:3,8,5:7,10:12)]
names(ExportTable2)=c("Spatial", "Water", "Prevalence", "Subpopulation", "MedianProp", "HEStD", "HE95% Quantile","MedianProp", "DTDStD", "DTD95% Quantile")
write.csv(ExportTable2, file=paste0("DataSummaryTable_WaterProportion_ProductProportion_", UID,"_",date,".csv"))



###Boxplots#### 
#The following script will prepare and produce the boxplots shown in the manuscript. The function below(plotprepare)
#can be adapted for each situation (HE, DTD, and subpopulations) using arguments. 

total_temp = as.data.frame(total_tbl) #"Total" subpopulation
we_temp  = as.data.frame(we_tbl) #"Both" subpopulation
nwe_temp = as.data.frame(nwe_tbl) #"Products-Only" subpopulation 



########Split plots into US and CA groups 

colorvec=brewer.pal(6, name="Paired")
cols=c("GW_low.tot"=colorvec[1],"GW_high.tot"=colorvec[2],"SW_low.tot"=colorvec[3], "SW_high.tot"=colorvec[4],
       "Mix_low.tot"=colorvec[5], "Mix_high.tot"=colorvec[6])
colslabs=c("GW_low.tot"="GW:Low","GW_high.tot"="GW:High","SW_low.tot"="SW:Low", "SW_high.tot"="SW:High",
           "Mix_low.tot"="MX:Low", "Mix_high.tot"="MX:High")

colspropprod=c("GW_low.prod"=colorvec[1],"GW_high.prod"=colorvec[2],"SW_low.prod"=colorvec[3], "SW_high.prod"=colorvec[4],
           "Mix_low.prod"=colorvec[5], "Mix_high.prod"=colorvec[6])
colslabspropprod=c("GW_low.prod"="GW:Low","GW_high.prod"="GW:High","SW_low.prod"="SW:Low", "SW_high.prod"="SW:High",
               "Mix_low.prod"="MX:Low", "Mix_high.prod"="MX:High")



plotprepare=function(X, var="tot_exp", PlotType=NULL,Subpop=NULL, UID="DED", date="", cols1=cols, colslabs1=colslabs, Prop=FALSE){
  Plot = reshape2::melt(X[grepl(var,names(X),)],value.name = 'Value')
  Facts=strsplit(as.character(Plot$variable), "_")
  Plot$Spatial=sapply(Facts, "[[", 1)
  Plot$Water=sapply(Facts, "[[", 2)
  Plot$Prev=sapply(Facts, "[[", 3)
  Plot$WaterPrev=paste0(Plot$Water,"_", Plot$Prev)
  agtab=aggregate(Value~variable+Spatial+Water + Prev,data=Plot, FUN="median")
  agtab$Water=factor(agtab$Water, levels=c("SW", "GW", "Mix"))
  agtab=agtab[order(agtab$Spatial, agtab$Water, agtab$Prev),]
  Plot$variable=factor(Plot$variable, levels=agtab$variable)
 
  xlabvec=agtab$Spatial
  if(PlotType=="HE" & Prop==FALSE){
    titlelab=paste0("Human Exposure (","\u00B5", "g/kg/day):", Subpop)
    ylabtitle1=paste0("Absorbed Dose (","\u00B5", "g/kg/day)")
    scalelims=c(1e-10, 1e-3)
  }else if(PlotType=="DTD" & Prop==FALSE){
    titlelab=paste0("Down the Drain Mass Released (g/day):", Subpop)
    ylabtitle1="Down the Drain Mass Released (g/day)"
    scalelims=c(1e-6,0.04)
  }else if(PlotType=="HE" & Prop==TRUE) {
    titlelab=paste0("Proportion of Human Exposure Due to Consumption of Contaminated Water:", Subpop)
    ylabtitle1="Proportion of Human Exposure due to Consumption of Contaminated Water"
  }else if (PlotType=="DTD" & Prop==TRUE){
    titlelab=paste0("Proportion of DTD Mass Released Due to Consumer Product Use:", Subpop)
    ylabtitle1="Proportion of DTD Mass Released Due to Consumer Product Use"
  }
  
  
  if(Prop==FALSE) {
    
    png(file = paste0(PlotType,"_", Subpop,"_", UID,"_", date,'.jpeg') ,
        height = 400,
        width = 1000)
    
    a=ggplot(data = Plot, aes(x = variable , y = Value, fill=WaterPrev)) +
      labs(x = "Spatial Scale", y = ylabtitle1, title = titlelab, fill=bquote(italic(Source:Prevalence[Product]))) + 
      scale_fill_manual(values=cols1, labels=colslabs1) +
#      theme(axis.title=element_text(size=15), title = element_text(size=20),
 #           legend.title = element_text(size=17), legend.text = element_text(size=15),
  #          axis.text=element_text(size=20), legend.key.size = unit(1,"cm"))+
      theme(axis.title=element_text(size=15), title = element_text(size=20),
            axis.text=element_text(size=20), legend.position = "none")+
      scale_y_log10(limits=scalelims) +
      scale_x_discrete(labels=xlabvec)+
      geom_boxplot()
    
    png(file = paste0(PlotType,"_", Subpop,"_", UID,"_", date,'.jpeg'),
        height = 400,
        width = 1000)
    print(a)
    dev.off()
  } else {
    
    
    a=ggplot(data = Plot, aes(x = variable , y = Value, fill=WaterPrev)) +
      labs(x = "Spatial Scale", y = ylabtitle1, title = titlelab, fill=bquote(italic(Source:Prevalence[Product]))) + 
      scale_fill_manual(values=cols1, labels=colslabs1) +
  #    theme(axis.title=element_text(size=15), title = element_text(size=15),
  #          legend.title = element_text(size=15), legend.text = element_text(size=15),
   #         axis.text=element_text(size=20),legend.key.size = unit(1,"cm"))+      
      theme(axis.title=element_text(size=15), title = element_text(size=15),
            axis.text=element_text(size=20), legend.position = "none")+      
      
            ylim(0,1) +
      scale_x_discrete(labels=xlabvec)+
      geom_boxplot()
      
    png(file = paste0(PlotType,"_", Subpop,"_PropWater_", UID,"_", date,'.jpeg'),
        height = 500,
        width = 1000)
    print(a)
    dev.off()
    
  }
  
  
  return(a)
}


####Save Plots####
setwd("C:/Users/ddawso01/OneDrive - Environmental Protection Agency (EPA)/Profile/Desktop/DioxaneDesktop/Portable_Workflow_Dawson_et_al_2021_DED121721/SHEDS_loop_Rev3_2021_12_22")
setwd('Plots')
#dir.create("Revised")
setwd("Revised")


##
colorvec=brewer.pal(6, name="Paired")
cols=c("GW_low.tot"=colorvec[1],"GW_high.tot"=colorvec[2],"SW_low.tot"=colorvec[3], "SW_high.tot"=colorvec[4],
       "Mix_low.tot"=colorvec[5], "Mix_high.tot"=colorvec[6])
colslabs=c("GW_low.tot"="GW:Low","GW_high.tot"="GW:High","SW_low.tot"="SW:Low", "SW_high.tot"="SW:High",
           "Mix_low.tot"="MX:Low", "Mix_high.tot"="MX:High")

colspropwat=c("GW_low.wat"=colorvec[1],"GW_high.wat"=colorvec[2],"SW_low.wat"=colorvec[3], "SW_high.wat"=colorvec[4],
               "Mix_low.wat"=colorvec[5], "Mix_high.wat"=colorvec[6])

colspropprod=c("GW_low.prod"=colorvec[1],"GW_high.prod"=colorvec[2],"SW_low.prod"=colorvec[3], "SW_high.prod"=colorvec[4],
               "Mix_low.prod"=colorvec[5], "Mix_high.prod"=colorvec[6])

colslabspropwat=c("GW_low.wat"="GW:Low","GW_high.wat"="GW:High","SW_low.wat"="SW:Low", "SW_high.wat"="SW:High",
                   "Mix_low.wat"="MX:Low", "Mix_high.wat"="MX:High")

colslabspropprod=c("GW_low.prod"="GW:Low","GW_high.prod"="GW:High","SW_low.prod"="SW:Low", "SW_high.prod"="SW:High",
                   "Mix_low.prod"="MX:Low", "Mix_high.prod"="MX:High")

##
#Create plots
Plot_1=plotprepare(total_temp, var="tot_exp", PlotType="HE", Prop=FALSE, Subpop="Total", date=date)#Human exposure: "Total" subpopulation
Plot_2=plotprepare(we_temp, var="tot_exp", PlotType = "HE", Prop=FALSE, Subpop="Both", date=date) #Human exposure: "Both" subpopulation
Plot_3=plotprepare(nwe_temp, var="tot_exp",PlotType = "HE", Prop=FALSE, Subpop="Products-Only", date=date)#Human exposure:"Products-Only" subpopulation 
Plot_4=plotprepare(we_temp, var="wat_prop_exp",cols1=colspropwat, colslabs1=colslabspropwat,  PlotType = "HE", Prop=TRUE, Subpop="Both", date=date)#Proportion of exposure from water: "Both" subpopulation
Plot_5=plotprepare(total_temp, var="wat_prop_exp", cols1=colspropwat, colslabs1=colslabspropwat,PlotType = "HE", Prop=TRUE, Subpop="Total", date=date)#Proportion of exposure from water: "Total" subpopulation
Plot_6=plotprepare(total_temp, var="tot_dtd",PlotType="DTD", Prop=FALSE, Subpop="Total", date=date)#DTD: "Total" subpopulation
Plot_7=plotprepare(we_temp, var="tot_dtd",PlotType="DTD", Prop=FALSE, Subpop="Both", date=date)#DTD: "Both" subpopulation
Plot_8=plotprepare(nwe_temp, var="tot_dtd",PlotType="DTD", Prop=FALSE, Subpop="Products-Only", date=date)#DTD:"Products-Only" subpopulation 
Plot_9=plotprepare(we_temp, var="prod_prop_dtd",cols1=colspropprod, colslabs1=colslabspropprod,PlotType="DTD", Prop=TRUE, Subpop="Both", date=date)#Proportion of DTD from water: "Both" subpopulation
Plot_10=plotprepare(total_temp, var="prod_prop_dtd",cols1=colspropprod, colslabs1=colslabspropprod,PlotType="DTD", Prop=TRUE, Subpop="Total", date=date)#Proportion of DTD from water: "Total" subpopulation

##Population Length
poplength=NULL
for(i in run_names){
col=which(names(we_temp)==paste0(i,".wat_prop_exp"))
poplength=c(poplength,length(which(is.na(we_temp[,col])==FALSE)))}
poplength=data.frame(poplength,"pop"=do.call("rbind",run_names))
