#Model prediction evaluation using 1,4 dioxane wastewater concentrations reported in literature and in databases.

#PREVIOUS SCRIPT IN WORKFLOW: Simulations_and_Data_Summary_IntReview.R
#ADDITIONAL Scripts in workflow: 
#Data_analysis_IntReview.R
#AA_Analysis_IntReview.R


#Thus scripts uses output from the ISTREEM web application to predict WWTP concentrations at various municipalities in the 
#ISTREEM database using the mean DTD concentrations produced by the factorial simulations. It then compares the distributions
#of values produced against distributions of empirical WWTP concentration data from Simonich et al. 2013 at a US national scale and data collected 
#by CalEPA at the state scale. Note that this does not include a statistical analysis.  


library(readxl)
library(openxlsx)
library(data.table)
library(ggplot2)

wd = dirname(rstudioapi::getSourceEditorContext()$path) #sets path to wherever the files reside
setwd(wd)

#Input in datalabel and runlabel corresponding to the factorial simulations run 
datelabel=date
runlabel=simulation_exp_name

#Read in output from ISTREEM model

USdata=read_xlsx("Wastewater_14Dioxane_Data/US_ISTREEM_WWTPP.xlsx")
USdata$State=substr(USdata$NPDES,1,2)
Caldata=USdata[USdata$MARKET==1,] #Note, CA is market number 1  

#Predict all DTD concentrations for all factorial combos and subpopulations
#Wastewater concentration (ug/L)is calculated by 
#multiplying the population served by the DDT(in g/day) giving total grams, divided
#by the flow rate(converted from Mgallons/day to liters/Day ). This value in g/l is
#multipled by 1000000 to convert it to ug/L. 
dtddata=read.csv(paste0("SHEDS_loop_", runlabel,"_", datelabel,"/DataSummaryTable.csv"))
dtddata=subset(dtddata, select=c("Spatial", "Water", "Prevalence","Subpopulation", "DTDMedian"))
wwconcdata=NULL
for(i in 1:length(dtddata[,1])){
sub=dtddata[i,]
if (sub$Spatial[1]=="CA"){
  ds=Caldata} else {ds=USdata}
  
ds$wwconc=((ds$P_SERVED * sub$DTDMedian)/(ds$FLOW * 3785411.8))*1000000 
ds=data.frame("Spatial"=sub$Spatial[1], "Water"=sub$Water[1], "Prev"=sub$Prevalence[1], "Subpopulation"= sub$Subpopulation[1], ds)
wwconcdata=rbind(wwconcdata, ds)}

wwconcdata$SpaceWater=paste0(wwconcdata$Spatial,"_", wwconcdata$Water)
wwconcdata=as.data.frame(wwconcdata)
wwconcsub=subset(wwconcdata,select=c("Spatial", "Water", "Prev", "Subpopulation", "State", "wwconc", "SpaceWater", "COMID","CUSEGMI","CWNS","NPDES","P_SERVED", "FLOW"))


#Read in CA and US 1,4 Dioxane WWTP concentration data
CalEPAdata=read_xlsx("Wastewater_14Dioxane_Data/CalEPA_WasteWaterData_14Dx.xlsx")
#Set ND to half MDL
CalEPAdata$Result=ifelse(is.na(CalEPAdata$Result)==FALSE, CalEPAdata$Result,ifelse(is.na(CalEPAdata$Result)==TRUE & is.na(CalEPAdata$MethodDetectionLimit)==FALSE, 0.5*CalEPAdata$MethodDetectionLimit,NA))
CalEPAdata=CalEPAdata[which(is.na(CalEPAdata$Result)==FALSE),]
dim(CalEPAdata)
CalEPAdata=CalEPAdata[,c("Location","Parameter", "Result", "MethodDetectionLimit", "Facility Name")]
names(CalEPAdata)[5]="Facility"


CalEPAdata$Spatial="CA"
CalEPAdata$Water="CA_Empirical"
CalEPAdata$Prev="CA_Empirical"
CalEPAdata$Subpopulation="Total"
CalEPAdata$SpaceWater="CA_Empirical"
CalEPAdata$State="CA"
CalEPAdata=data.frame(CalEPAdata$Spatial, CalEPAdata$Water, CalEPAdata$Prev, 
                      CalEPAdata$Subpopulation, CalEPAdata$State, CalEPAdata$Result, CalEPAdata$SpaceWater, CalEPAdata$Facility, "Source"="CalEPA")

CalEPAdata2=CalEPAdata
CalEPAdata2$CalEPAdata.Subpopulation="Products Only"
CalEPAdata3=CalEPAdata
CalEPAdata3$CalEPAdata.Subpopulation="Both"

Sim=read.xlsx("Wastewater_14Dioxane_Data/Simonich_Dioxane_data_2011_fromPB.xlsx")
Sim=subset(Sim, select=c("Sample.ID", "Result.(ug/L)"))
Sim$Spatial="US"
Sim$Water="US_Empirical"
Sim$Prev="US_Empirical"
Sim$Subpopulation="Total"
Sim$SpaceWater="US_Empirical"
Sim$State="US"
Sim$Facility="NA"
Sim=data.frame(Sim$Spatial, Sim$Water, Sim$Prev, 
                      Sim$Subpopulation, Sim$State, Sim$Result, Sim$SpaceWater, Sim$Facility, "Source"="Simonich")

Sim2=Sim
Sim2$Sim.Subpopulation="Products Only"
Sim3=Sim
Sim3$Sim.Subpopulation="Both"


library(data.table)
Empirical=as.data.frame(rbindlist(list(CalEPAdata, CalEPAdata2,CalEPAdata3, Sim,Sim2,Sim3), use.names=FALSE))

#Combine Sim and Emperical sets
Empirical$COMID=NA
Empirical$CUSEGMI=NA
Empirical$CWNS=NA
Empirical$NPDES=NA
Empirical$P_SERVED=NA
Empirical$Flow=NA


wwconcsub=data.frame(wwconcsub[,1:7], "Facility"=NA, "Source"= "ISTREEM", wwconcsub[,8:13])
wwconcsub1=as.data.frame(rbindlist(list(wwconcsub, Empirical), use.names=FALSE))
wwconcsub1$SpaceWater=factor(wwconcsub1$SpaceWater, levels=c("US_GW", "US_Mix", "US_SW", "US_Empirical",
                                                              "CA_GW", "CA_Mix", "CA_SW", "CA_Empirical"))
wwconcsub1$Prev=factor(wwconcsub1$Prev, levels=c("low", "high", "US_Empirical", "CA_Empirical"))


write.csv(wwconcsub1, file=paste0("SHEDS_loop_", runlabel,"_", datelabel,"/WWvalidation_compiled_Data_", runlabel,"_", datelabel,".csv"))

#Total
library(ggplot2)
#1000 X 704
wwcomptotal=ggplot(aes(x=SpaceWater, y=wwconc, fill=Prev), data=wwconcsub1[c(wwconcsub1$Subpopulation=="Total" | wwconcsub1$Subpopulation=="CA_Empirical" | wwconcsub1$Subpopulation=="US_Empirical"),]) +
  geom_boxplot()+
  coord_flip()+
labs(title="Wastewater Influent Concentration: Total")+
  xlab("Spatial Water Source")+
  ylab(expression("Wastewater Influent Concentration ("*mu*"g/L)"))+
  guides(fill=guide_legend("Prevalence"))+
  scale_fill_hue(labels=c("Low", "High", "US Empirical Data", "CA Empirical Data"))+
  scale_y_continuous(limits=c(0,10))
 

png(file = paste0("SHEDS_loop_",runlabel, "_", datelabel,"/Plots/DTD_Wastewater_Conc_Evaluation_Total.png"),
    height = 500,
    width = 800)

wwcomptotal

dev.off()


#Products Only
wwcomppo=ggplot(aes(x=SpaceWater, y=wwconc, fill=Prev), data=wwconcsub1[c(wwconcsub1$Subpopulation=="Products Only" | wwconcsub1$Subpopulation=="CA_Empirical" | wwconcsub1$Subpopulation=="US_Empirical"),]) +
  geom_boxplot()+
  coord_flip()+
  labs(title="Wastewater Influent Concentration: Products Only")+
  xlab("Spatial Water Source")+
  ylab(expression("Wastewater Influent Concentration ("*mu*"g/L)"))+
  guides(fill=guide_legend("Prevalence"))+
  scale_fill_hue(labels=c("Low", "High", "US Empirical Data", "CA Empirical Data"))+ 
  scale_y_continuous(limits=c(0,10))

png(file = paste0("SHEDS_loop_",runlabel, "_", datelabel,"/Plots/DTD_Wastewater_Conc_Evaluation_ProductsOnly.png"),
    height = 500,
    width = 800)

wwcomppo

dev.off()


#Both
wwcompboth=ggplot(aes(x=SpaceWater, y=wwconc, fill=Prev), data=wwconcsub1[c(wwconcsub1$Subpopulation=="Both" | wwconcsub1$Subpopulation=="CA_Empirical" | wwconcsub1$Subpopulation=="US_Empirical"),]) +
  geom_boxplot()+
  coord_flip()+
  labs(title="Wastewater Influent Concentration: Both")+
  xlab("Spatial Water Source")+
  ylab(expression("Wastewater Influent Concentration ("*mu*"g/L)"))+
  guides(fill=guide_legend("Prevalence"))+
  scale_fill_hue(labels=c("Low", "High", "US Empirical Data", "CA Empirical Data")) +
  scale_y_continuous(limits=c(0,10))

  png(file = paste0("SHEDS_loop_",runlabel, "_", datelabel,"/Plots/DTD_Wastewater_Conc_Evaluation_Both.png"),
    height = 500,
    width = 800)

wwcompboth

dev.off()



Valtab=NULL
for(j in unique(wwconcsub1$SpaceWater)){
  for(i in c("Total", "Products Only", "Both")){
    for(k in c("low", "high","US_Empirical", "CA_Empirical")){
        set=wwconcsub1[c(wwconcsub1$SpaceWater==j & wwconcsub1$Subpopulation==i & wwconcsub1$Prev==k),]

  meanval=median(set$wwconc)
  sdval=sd(set$wwconc)
  Q95=quantile(set$wwconc, probs=0.95)
  Valtab=rbind(Valtab, c(meanval, sdval, Q95,j,i,k))
  }}}

Valtab=as.data.frame(Valtab)
names(Valtab)=c("Median", "SD","Q95", "SpaceWater", "Subpopulation", "Prevalence")
names=strsplit(Valtab$SpaceWater,"_")
names=do.call("rbind", names)
Valtab$Space=names[,1]
Valtab$Water=names[,2]

Valtab=na.omit(Valtab) #Clean up non values
Valtab$Median=as.numeric(Valtab$Median)
Valtab$SD=as.numeric(Valtab$SD)
Valtab$Q95=as.numeric(Valtab$Q95)

#Arrange for supplemental table
Valtab=data.frame("Space"=Valtab$Space, "Water"=Valtab$Water, "Prevalence"= Valtab$Prevalence, "Median"=Valtab$Median, "SD"=Valtab$SD, "Q95%"=Valtab$Q95,"Subpopulation"=Valtab$Subpopulation)
Valtab$Subpopulation=factor(Valtab$Subpopulation, levels=c("Total","Products Only", "Both"))
Valtab=Valtab[order(Valtab$Subpopulation),]

Empdat=subset(Valtab,Water=="Empirical")
Valtab=Valtab[-c(which(Valtab$Water=="Empirical")),]
Valtab=rbind(Empdat[1:2,], Valtab)

write.csv(Valtab, file=paste0("SHEDS_loop_",runlabel, "_", datelabel,"/WWvalidation_Dataset_US_CA.csv"))

